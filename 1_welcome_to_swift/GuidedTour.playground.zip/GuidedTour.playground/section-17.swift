shoppingList = []   // Went shopping and bought everything.
